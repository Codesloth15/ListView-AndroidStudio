package com.example.mynew;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class IceCream extends AppCompatActivity {
ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ice_cream);
        listView = findViewById(R.id.list_item);
        ArrayList<String> arrayList = new ArrayList<>();
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(IceCream.this, android.R.layout.simple_list_item_1, arrayList);
        arrayList.add("Vanilla");
        arrayList.add("Chocolate");
        arrayList.add("Strawberry");
        arrayList.add("Mint Chip");
        arrayList.add("Cookies and Cream");
        arrayList.add("Rocky Road");
        arrayList.add("Butter Pecan");
        arrayList.add("Pistachio");
        arrayList.add("Coffee");
        arrayList.add("Maple Walnut");
        arrayList.add("Caramel Swirl");
        arrayList.add("Banana Split");
        arrayList.add("Coconut");
        arrayList.add("Raspberry Ripple");
        arrayList.add("Tiramisu");
        arrayList.add("Hazelnut");
        arrayList.add("Bubblegum");
        arrayList.add("Peach");
        arrayList.add("Cherry");
        arrayList.add("Lemon Sorbet");
        listView.setAdapter(arrayAdapter);

    }
}