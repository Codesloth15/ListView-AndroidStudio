package com.example.mynew;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class Hamburger extends AppCompatActivity {
    ListView listView; //name of the ListView
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hamburger);
        listView = findViewById(R.id.list_item);
        ArrayList<String> arrayList = new ArrayList<>();
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(Hamburger.this, android.R.layout.simple_list_item_1, arrayList);
        arrayList.add("Classic Burger");
        arrayList.add("Cheeseburger");
        arrayList.add("Bacon Burger");
        arrayList.add("Mushroom Swiss Burger");
        arrayList.add("BBQ Burger");
        arrayList.add("Veggie Burger");
        arrayList.add("Turkey Burger");
        arrayList.add("Chicken Burger");
        arrayList.add("Double Patty Burger");
        arrayList.add("Teriyaki Burger");
        arrayList.add("Guacamole Burger");
        arrayList.add("Jalapeno Burger");
        arrayList.add("Avocado Burger");
        arrayList.add("Pineapple Burger");
        arrayList.add("Blue Cheese Burger");
        arrayList.add("Western Burger");
        arrayList.add("Black Bean Burger");
        arrayList.add("Hawaiian Burger");
        arrayList.add("Mushroom Swiss Turkey Burger");
        arrayList.add("Buffalo Burger");
        arrayList.add("Spicy Burger");

        listView.setAdapter(arrayAdapter);

    }
}