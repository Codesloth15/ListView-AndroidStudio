package com.example.mynew;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class Beer extends AppCompatActivity {
ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beer);
        listView = findViewById(R.id.list_item);
        ArrayList<String> arrayList = new ArrayList<>();
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(Beer.this, android.R.layout.simple_list_item_1, arrayList);
        arrayList.add("IPA");
        arrayList.add("Stout");
        arrayList.add("Lager");
        arrayList.add("Pilsner");
        arrayList.add("Porter");
        arrayList.add("Wheat Beer");
        arrayList.add("Belgian Ale");
        arrayList.add("Saison");
        arrayList.add("Amber Ale");
        arrayList.add("Pale Ale");
        arrayList.add("Brown Ale");
        arrayList.add("Sour Ale");
        arrayList.add("Hefeweizen");
        arrayList.add("Bock");
        arrayList.add("Doppelbock");
        arrayList.add("Cream Ale");
        arrayList.add("Scottish Ale");
        arrayList.add("Irish Red Ale");
        arrayList.add("Barleywine");
        arrayList.add("Gose");
        listView.setAdapter(arrayAdapter);




    }
}