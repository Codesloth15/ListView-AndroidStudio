package com.example.mynew;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class HotDog extends AppCompatActivity {
ListView listView;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hot_dog);
        listView = findViewById(R.id.list_item);
        ArrayList<String> arrayList = new ArrayList<>();
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(HotDog.this, android.R.layout.simple_list_item_1, arrayList);
        arrayList.add("Classic Hot Dog");
        arrayList.add("Chili Cheese Dog");
        arrayList.add("Chicago Dog");
        arrayList.add("Bacon-Wrapped Dog");
        arrayList.add("Bratwurst");
        arrayList.add("Pretzel Dog");
        arrayList.add("Corn Dog");
        arrayList.add("Kielbasa");
        arrayList.add("Sausage Dog");
        arrayList.add("Veggie Dog");
        arrayList.add("Gourmet Hot Dog");
        arrayList.add("Buffalo Hot Dog");
        arrayList.add("Jalapeno Dog");
        arrayList.add("Hawaiian Dog");
        arrayList.add("Philly Cheesesteak Dog");
        arrayList.add("Kimchi Dog");
        arrayList.add("Reuben Dog");
        arrayList.add("BBQ Bacon Dog");
        arrayList.add("Teriyaki Dog");
        arrayList.add("Pulled Pork Dog");
        listView.setAdapter(arrayAdapter);
    }
}