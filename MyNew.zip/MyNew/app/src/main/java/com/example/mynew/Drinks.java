package com.example.mynew;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class Drinks extends AppCompatActivity {
ListView listView;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drinks);


        listView = findViewById(R.id.list_item);
        ArrayList<String> arrayList = new ArrayList<>();
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(Drinks.this, android.R.layout.simple_list_item_1, arrayList);
        arrayList.add("Soda");
        arrayList.add("Water");
        arrayList.add("Iced Tea");
        arrayList.add("Lemonade");
        arrayList.add("Smoothie");
        arrayList.add("Milkshake");
        arrayList.add("Fruit Juice");
        arrayList.add("Energy Drink");
        arrayList.add("Sparkling Water");
        arrayList.add("Hot Chocolate");
        arrayList.add("Frappe");
        arrayList.add("Mojito");
        arrayList.add("Cappuccino");
        arrayList.add("Punch");
        arrayList.add("Mocktail");
        arrayList.add("Green Tea");
        arrayList.add("Margarita");
        arrayList.add("Coconut Water");
        arrayList.add("Lassi");

        listView.setAdapter(arrayAdapter);
    }
}