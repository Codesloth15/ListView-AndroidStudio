package com.example.mynew;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class Coffee extends AppCompatActivity {
ListView listView;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coffee);
        listView = findViewById(R.id.list_item);
       ArrayList<String> arrayList = new ArrayList<>();
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(Coffee.this, android.R.layout.simple_list_item_1,arrayList);
        arrayList.add("Espresso");
        arrayList.add("Cappuccino");
        arrayList.add("Latte");
        arrayList.add("Mocha");
        arrayList.add("Americano");
        arrayList.add("Flat White");
        arrayList.add("Macchiato");
        arrayList.add("Iced Coffee");
        arrayList.add("Cold Brew");
        arrayList.add("Turkish Coffee");
        arrayList.add("Irish Coffee");
        arrayList.add("Vienna Coffee");
        arrayList.add("Affogato");
        arrayList.add("Cortado");
        arrayList.add("French Press");
        arrayList.add("AeroPress");
        arrayList.add("Pour Over");
        arrayList.add("Bulletproof Coffee");
        arrayList.add("Ristretto");
        arrayList.add("Decaf");
    listView.setAdapter(arrayAdapter);
    }
}